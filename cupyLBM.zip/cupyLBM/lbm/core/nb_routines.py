import cupy as np
import numba as nb


nb.set_num_threads(10)



def density(f, rho):
    #rho[idx_internal] = np.sum(f[:, idx_internal], axis=0)
    rho[:] = np.sum(f, axis=0)



def velocity(f, rho, u, c, d):
    for i in nb.prange(d):
        u[:, i] = np.dot(c[:, i], f)/rho
        #u[i] = np.dot(c[:, i], f)/rho



def force_velocity(f, rho, u, g, c, d):
    for i in nb.prange(d):
        u[:, i] = np.dot(c[:, i], f)
        #u[i] = np.dot(c[:, i], f)
    u += 0.5*g
    for i in nb.prange(d):
        u[:, i] /= rho
        #u[i] /= rho



def source_force(S, S_const, u, g, c, q, inv_cs_2):
    for i in nb.prange(q):
        tmp = (np.outer(np.dot(u, c[i]) * inv_cs_2 + 1, c[i]) - u) * g
        S[i, :] = S_const[i] * np.sum(tmp, axis=1)



def force(g, rho, d, force_vector):
    for i in nb.prange(d):
        g[:, i] = rho * force_vector[i]
        #g[i] = rho * force_vector[i]



def equilibrium(feq, u, rho, q, w, c, inv_cs_2, inv_cs_4):
    u = u
    rho = rho
    uu = np.sum(u**2, axis=1)
    #uu = np.sum(u**2, axis=0)
    for i in nb.prange(q):
        uc = np.dot(u, c[i])
        #uc = np.dot(c[i], u)
        feq[i, :] = w[i]*rho*(1 + uc*inv_cs_2 + 0.5*uc**2*inv_cs_4 - 0.5*uu*inv_cs_2)



def collision_bgk(f, feq, source, omega):
    f += source - omega * (f - feq)



def collision_trt(f, feq, source, i_opp, omega_plus, omega_minus):
    #f += source - 0.5*(omega_plus + omega_minus) * (f - feq) - 0.5*(omega_plus - omega_minus) * (f[i_opp] - feq[i_opp])
    f += source - 0.5*(omega_plus + omega_minus) * (f - feq)
    f[i_opp] -= 0.5*(omega_plus - omega_minus) * (f - feq)
    #for i in nb.prange(f.shape[1]):
    #    f_p = 0.5 * (f[:, i] + f[i_opp, i])
    #    f_m = 0.5 * (f[:, i] - f[i_opp, i])
    #    f_eq_p = 0.5 * (feq[:, i] + feq[i_opp, i])
    #    f_eq_m = 0.5 * (feq[:, i] - feq[i_opp, i])
    #    f[:, i] += source[:, i] - omega_plus * (f_p - f_eq_p) - omega_minus * (f_m - f_eq_m)



def streaming_bulk(f, f0, q, streaming_map_bulk, index):
    for i in nb.prange(q):
        f[i, index] = f0[i, streaming_map_bulk[i]]



def streaming_boundary(f, f0, streaming_map_boundary):
    for idx in nb.prange(streaming_map_boundary.shape[0]):
        # streaming map contains:
        # [i, 0]: cell destination index
        # [i, 1]: cell source index
        # [i, 2]: population index
        cell_idx = streaming_map_boundary[idx, 0]
        cell0_idx = streaming_map_boundary[idx, 1]
        i = streaming_map_boundary[idx, 2]
        #print(f"streaming \tf{i}:{cell_idx} = f{i}:{cell0_idx}")
        f[i, cell_idx] = f0[i, cell0_idx]



def boundary_bounce_back(f, f0, streaming_map, wall_data):
    # streaming map contains:
    # [i, 0]: cell index
    # [i, 1]: population index destination
    # [i, 2]: population index source
    for idx in nb.prange(streaming_map.shape[0]):
        cell_index = streaming_map[idx, 0]
        i_opp = streaming_map[idx, 1]
        i = streaming_map[idx, 2]
        #print(f"boundary_bounce_back \tf{i_opp}:{cell_index} = f{i}:{cell_index}    wall data_{i}: {wall_data[i]}")
        f[i_opp, cell_index] = f0[i, cell_index] + wall_data[i]



def wall_data_anti_bounce_back(u, c, w, inv_cs_2, inv_cs_4, rho_wall, i_c, i_c_n, ii):
    u_wall = 1.5*u[i_c] - 0.5*u[i_c_n]
    #print(f"\t\t\t\t u_w =  1.5*u[{i_c}] - 0.5*u[{i_c_n}]")
    return 2.0 * w[ii] * rho_wall * \
             (1 +
              0.5 * np.dot(c[ii], u_wall)**2 * inv_cs_4 -
              0.5 * np.dot(u_wall, u_wall) * inv_cs_2)



def boundary_anti_bounce_back(f, f0, u, streaming_map, rho_wall, w, c, inv_cs_2, inv_cs_4):
    # streaming map contains:
    # [i, 0]: cell index
    # [i, 1]: cell neighbour index
    # [i, 2]: population index destination
    # [i, 3]: population index source
    for idx in nb.prange(streaming_map.shape[0]):
        i_c = streaming_map[idx, 0]
        i_c_n = streaming_map[idx, 1]
        i_opp = streaming_map[idx, 2]
        i = streaming_map[idx, 3]
        #print(f"boundary_anti_bounce_back \tf{i_opp}:{i_c} = - f{i}:{i_c}")
        f[i_opp, i_c] = - f0[i, i_c] + wall_data_anti_bounce_back(u, c, w, inv_cs_2, inv_cs_4,
                                                                  rho_wall, i_c, i_c_n, i)



def boundary_symmetry(f, f0, streaming_map):
    # streaming map contains:
    # [i, 0]: cell index
    # [i, 1]: cell symmetry index
    # [i, 2]: population index destination
    # [i, 3]: population index source
    for idx in nb.prange(streaming_map.shape[0]):
        i_c = streaming_map[idx, 0]
        i_c_s = streaming_map[idx, 1]
        i_s = streaming_map[idx, 2]
        i = streaming_map[idx, 3]
        #print(f"boundary_symmetry \tf{i_s}:{i_c} = f{i}:{i_c_s}")
        f[i_s, i_c] = f0[i, i_c_s]


def boundary_periodic():
    pass
