import cupy as np
from lbm.core.bc.boundary_condition import BoundaryCondition
from lbm.core.bc import BoundaryType, BoundaryClass
from lbm.core.stencil import Stencil
from lbm.mesh.cell import Cell
from lbm.mesh.face import Face
import lbm.core.nb_routines as nb_routines


class BounceBack(BoundaryCondition):
    def __init__(self, name='BounceBack', velocity=None, density=np.float64(1.0), capacity=0):
        super().__init__(name, BoundaryType.BOUNCE_BACK, BoundaryClass.WALL)
        self.streaming_map = np.empty((capacity, 3), dtype=np.uint32)
        self.velocity = velocity
        self.density = density
        if self.velocity is not None:
            self.boundary_type = BoundaryClass.EXTERNAL

    def __repr__(self):
        if self.velocity is None:
            return super().__repr__()
        else:
            return f"<{self.boundary_type}:TYPE:{self.boundary_type}:" \
                   f"{self.name},velocity={*self.velocity,},density={self.density}>"

    def streaming(self, lattice, stencil):
        nb_routines.boundary_bounce_back(lattice.f, lattice.f0, self.streaming_map, self.wall_data)

    def setup_streaming(self, pop_idx, cell: Cell, faces: list[Face], stencil):
        streaming_map = np.array([cell.index, pop_idx, stencil.i_opp[pop_idx]],
                                 dtype=np.uint32)
        self.push_back(streaming_map)

    def setup_boundary_data(self, stencil: Stencil):
        self.wall_data = np.zeros(stencil.q, dtype=np.float64)
        if self.velocity is not None:
            for i in range(stencil.q):
                self.wall_data[i] = - 2 * stencil.w[i] * self.density *\
                                    np.dot(stencil.c[i], self.velocity) / stencil.cs**2
